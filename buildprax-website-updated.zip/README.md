# BUILDPRAX Website

This is the official website for BUILDPRAX MEASURE PRO - Professional measurement software for construction estimating.

## Files Structure

```
website/
├── index.html              # Main landing page
├── styles.css              # Website styling
├── script.js               # Website functionality
├── installation-guide.html # Installation instructions
├── assets/
│   └── logo.png            # BUILDPRAX logo
└── downloads/
    ├── install-app.sh      # Installation script
    └── INSTALLATION_INSTRUCTIONS.md
```

## Features

- **Professional Design**: Modern, responsive design that works on all devices
- **Clear Value Proposition**: Highlights the key benefits of the software
- **Easy Downloads**: Direct download links with installation help
- **Pricing Information**: Transparent pricing with free trial
- **Support Section**: Multiple ways to get help
- **SEO Optimized**: Proper meta tags and structure

## Setup Instructions

1. **Upload to your web server** (GoDaddy, etc.)
2. **Add your DMG file** to the `downloads/` folder
3. **Update the download link** in `index.html` to point to your actual DMG file
4. **Configure email** to use `support@buildprax.com`
5. **Test all links** and functionality

## Customization

### Colors
The website uses a professional color scheme:
- Primary: `#065f46` (Dark Green)
- Secondary: `#10b981` (Green)
- Background: `#f8fafc` (Light Gray)
- Text: `#1a202c` (Dark Gray)

### Content Updates
- Edit `index.html` for text content
- Modify `styles.css` for visual changes
- Update `script.js` for functionality

## Analytics Integration

To add Google Analytics or other tracking:

1. Add tracking code to `<head>` section of `index.html`
2. Uncomment analytics tracking in `script.js`
3. Configure conversion tracking for downloads

## Next Steps

1. **Domain Setup**: Point buildprax.com to your web server
2. **SSL Certificate**: Enable HTTPS for security
3. **Email Setup**: Configure support@buildprax.com
4. **Payment Integration**: Add Stripe/PayPal for license purchases
5. **Content Management**: Consider adding a CMS for easy updates

## Support

For website support or modifications, contact the development team.

---

*Built for BUILDPRAX MEASURE PRO - Professional construction measurement software*
